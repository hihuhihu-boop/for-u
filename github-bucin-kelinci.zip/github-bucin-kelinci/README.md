# Surat kecil untuk Sayang 💌

Website bucin dengan satu karakter kelinci pembawa surat dari gambar yang kamu pilih.
Tampilan pastel biru, ungu, dan pink; tiga tombol interaktif untuk membuka pesan Ngambek, Kepo, dan Manja; animasi teks dan hati; responsif untuk HP.

## Struktur file
- `index.html`
- `assets/kelinci-surat.jpg`

Penting: upload `index.html` dan folder `assets` beserta gambarnya ke repository GitHub. Jika gambar tidak diunggah, karakter tidak akan muncul.

## Cara tes
Ekstrak ZIP, lalu buka `index.html` lewat browser. Pastikan folder `assets` berada satu tingkat dengan `index.html`.

## Cara publish dengan GitHub Pages
1. Buat repository baru di GitHub, misalnya `website-bucin`, pilih Public.
2. Upload `index.html` dan folder `assets` (termasuk `kelinci-surat.jpg`).
3. Klik Commit changes.
4. Buka Settings → Pages.
5. Pada Build and deployment, pilih Deploy from a branch.
6. Pilih branch `main` dan folder `/(root)`, lalu klik Save.
7. Tunggu beberapa menit sampai proses selesai.
8. Website biasanya tersedia di `https://USERNAME.github.io/website-bucin/` (ganti USERNAME dengan username GitHub kamu).

GitHub Pages bersifat publik. Jangan masukkan informasi pribadi atau rahasia.
